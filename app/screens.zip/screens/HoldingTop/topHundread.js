import React, { PropTypes } from 'react';
import firebase from 'react-native-firebase';
import { TouchableOpacity,ScrollView, Text,View,Image, StyleSheet, AsyncStorage } from 'react-native';
import { Dimensions } from 'react-native';
import { ProgressDialog } from 'react-native-simple-dialogs';
class TopHundread extends React.Component
{
  user = [];
  friendList = [];
  finalList = [];
  constructor(props) {
    super(props);
    this.state={
        userImage: require('./../../../assets/images/user.png'),
        name:'wilson benedict Lim',
        text:'M = 800000 % P.A.',
        user:[],
        quaterdata:[],
        loading : true,
        myId:'', 
        friendList:[], 
        finalList:[],
        quarter:this.props.quarter,
        date:this.props.date
    };
    this.getvalue();
    this.getMyId();
  }    
   filter(text){
     let alldata;
     debugger
     alldata=this.state.user;
     if(text=='')
     {
       this.setState({user:this.user})
     }
     else{
     let filterarr=[];
      this.user.forEach((da,i)=>{
       let user=da.name 
      if((user.toLowerCase()).includes(text.toLowerCase()) )
      {
        filterarr.push(da);
      }
     })
      this.setState({user: filterarr})
     console.log("data1"+" "+ this.state.data );  
   }
   } 
 
   componentDidMount() {
    let that=this;
    this.willFocusSubscription = this.props.navigation.addListener(
      'willFocus',
      () => { 
        
          that.getListOfFriend( );
       
      }
    ); 
  }

   getListOfFriend(id ,type , keyy){ 
     debugger
     this.setState({loading:true});
     console.log('idddd',id);
     let url='users/'+this.state.myId+'/friends';
     let that=this;
     let indexnum=Number;
     firebase.database().ref(url).once('value').then((data)=>{
       console.log('tttt',data.val())
       let friendData=data.val();
       if(friendData==null){
         that.finalList=[];
         that.setState({finalList:that.finalList});
         if(id!=undefined){
           that.finalList.push(id);
           that.setState({finalList:that.finalList});
         }
       }else{
         if(type==undefined){
            Object.keys(friendData).forEach(function(key){
              that.finalList.push(friendData[key]['id']);
              console.log('finalList',that.finalList);
              that.setState({finalList:that.finalList});
            });
         }
         else{
           if(type=='0'){
             that.finalList.push(id);
             that.setState({finalList:that.finalList});
           }
           else if(type=='1'){
             that.finalList.forEach((data,key)=>{
               if(data==id){
                 indexnum=key;
                 return;
               }
            });
            firebase.database().ref('users/'+this.state.myId+'/friends').child(keyy).remove().then(()=>{
              that.finalList.splice(indexnum, 1);
            that.setState({finalList:that.finalList});
            });
            
           }
         }
         
       }
       this.setState({loading:false});
     })
   }
   getvalue(){ 
      let date=new Date();
      let url;
      let url1 = 'users/'
      let that = this;
      let month=date.getMonth()+1;
      let meuData1=[];
      let tempUser=[];
      let length=0;
      url=this.state.quarter;
     firebase.database().ref(url).once('value').then((data) => {
          Object.keys(data.val()).map((key)=>{ 
            let dd=data.val()[key];
            console.log("userlistarray*********",key);
            firebase.database().ref(url1+key).once('value').then((da) => { 
              let userd=da.val();
              length=Object.keys(da.val()).length;
              userd['meu']=dd.meu;
              that.user.push(userd);
              that.user = that.user.sort(function(a, b){return b.meu - a.meu})
              that.setState({user : that.user},()=>{
                console.log('uuuuu',this.user); 
              });
              }).catch((err)=>{
              console.log(JSON.stringify(err))
             });
          });
          console.log(that.state.user);
           that.setState({quaterdata: meuData1},()=>{
          });
          that.getMyFriends();
        }).catch((err)=>{
           console.log(JSON.stringify(err))
        });
    }
 

    addFriend(friendData, index){
    if(this.state.finalList.length>=9999){
      alert('you can add max 9,999 number of Friends');
    }else{
      this.setState({loading:true}); 
      let url = "users/"+this.state.myId+"/friends";
      let that=this;
      this.state.user[index]['isFriend'] = true;
      this.setState(this.state.user) ; 
      firebase.database().ref(url).push(friendData).then(() => {  
        that.getListOfFriend(friendData.id,'0');
      });
    }
  
    }
    removeFriend(allData,ind){
      this.setState({loading:true});
       let url='users/'+this.state.myId+'/friends';
       let that=this; 
       firebase.database().ref(url).once('value').then((data) => {
          let allDatalist = data.val();
          Object.keys(allDatalist).forEach(function(key){
            if(allDatalist[key]['id']==allData['id']){
              that.getListOfFriend(allData.id,'1',key);
            }
          });
       });
    }
    delete(){
      
    }
    getMyFriends(){
       let friendsUrl = "users/"+this.state.myId+"/friends";
             let that = this;
              firebase.database().ref(friendsUrl).once('value').then((data) => {
                console.log("friends array************", data.val());
                if(data.val()!=null){
                  Object.keys(data.val()).map((key)=>{ 
                    let dd=data.val()[key];
                    console.log("Key**********",key);
                    console.log("value**********", dd);
                    that.friendList.push(dd.id);
                    that.setState({friendList:that.friendList},()=>{
                    });
                    console.log("friendlistarray**********", that.friendList);
                  });
                }
                that.setState({loading:false});
                // that.getSelectedOne(that.friendList);
              }).catch((err)=>{
                console.log("this is error", err);
              });  
    }

    async getMyId(){
      var user = await AsyncStorage.getItem('user');
      console.log("myid********", user);
      var userId = JSON.parse(user);
      console.log("myid*******new", userId.id);
      this.setState({myId:userId.id},()=>{
        this.getListOfFriend();
      })
    }
    // openHolding(id){ 
    //   debugger
    //   this.props.all.props.navigation.navigate('userHolding',{date:this.props.date,'quater':this.props.quarter,'id':id});
    //   // this.props.navigation.navigate('userHolding',{date:this.state.date,'quater':q});
    // }
  checkIsFriend(id){
    console.log("iddddddd", id)
    console.log("friendList", this.friendList);
    console.log(this.finalList.indexOf(id)==-1 ? false : true);
    return this.finalList.indexOf(id)==-1 ? false : true;
  }
  openUserHolding(userId, name,url,points,rank,meu, friendStatus,userData){ 
   this.props.navigation.navigate('userHolding',{date:this.props.date,'quater':this.props.quarter,'userId':userId,'name':name,'imageUrl': url,'points':points,'rank':rank,'meu':meu,'friendStatus':friendStatus,'userData':userData,'loginUserId':this.state.myId,friendPage:false});
  }
  render()
  { 
    let mydata;
    let mydatavalue =null;
    let myRank;
    let d;
    let meu;
    let id;
    let list=this.state.user.map((UserData, jIndex,array) =>{ 
      
        let index;
        if(jIndex!=0){
          let aa=array;
          console.log(aa);
          console.log(aa[jIndex-1].meu)
          
          if(UserData.meu==aa[jIndex-1].meu){
              myRank=jIndex;
              index=<Text style={styles.ranktext}>#{jIndex}</Text>
             }
            else{
              myRank=jIndex+1;
              index=<Text style={styles.ranktext}>#{jIndex+1}</Text>
             }
          }
          else if(jIndex==0){
            myRank=jIndex+1;
            index=<Text style={styles.ranktext}>#{jIndex+1}</Text>
          } 
          if(UserData.id==this.state.myId){
            mydatavalue=UserData;
          }
         let d=UserData.picture.data.url;
         let id=UserData.id;
         let meuView;
         if(UserData.meu==undefined){
            meuView= <Text style={{fontSize:12 }}>μ =0% p.a.</Text>
            meu=0
         }
         else{
          meuView= <Text style={{fontSize:12 }}>μ ={parseFloat(UserData.meu).toFixed(3)}% p.a.</Text>
          meu=parseFloat(UserData.meu).toFixed(3)
         }
       
        return ( <View style={styles.contain} key={jIndex}>
                    <View style={styles.rankContainer}>
                    {index}
                    </View>
                    <View style={styles.viewContainer}>
                        <TouchableOpacity style={{flex:2,flexDirection:'row'}}onPress={this.openUserHolding.bind(this,UserData.id,UserData.name,UserData.picture.data.url,UserData.points,index,meu,this.checkIsFriend(UserData.id),UserData)}>
                          <View style={{flex:1}}>
                           <Image  style={{width:45,height:45,borderRadius: 45/2}} source={{uri: d}}></Image>
                          </View>
                          <View style={{flex:3,flexDirection:'row',paddingLeft:10}}>
                            <View style={{flex:1,flexDirection:'column'}}>
                              <Text style={{fontSize:15,color:'#000'}}>{UserData.name}</Text>
                              {meuView}
                            </View>
                          </View>
                        </TouchableOpacity> 
                        {  this.checkIsFriend(UserData.id) ? 
                        
                        <TouchableOpacity style={this.state.myId==UserData.id?'':styles.alreadyFriend}>
                            <Text  style={styles.friendText} onPress={this.removeFriend.bind(this, UserData, jIndex)}> Remove Friend</Text>
                        </TouchableOpacity> : 
                         <TouchableOpacity style={this.state.myId==UserData.id?'':styles.addFriend} onPress={this.addFriend.bind(this, UserData, jIndex)}>
                            <Text style={styles.friendText}> Add Friend</Text>
                        </TouchableOpacity> }
                    </View>
               </View>
        );
      //}
  });   
    return( 
      <View style={{height: Dimensions.get('window').height-250,}}>
        <ScrollView contentContainerStyle={styles.container}>
            <View style={{flex:1, flexDirection:'row'}}>
              <View style={{flex:1, alignItems:'flex-start'}}>
              <Text style={styles.heading}> Top 100 this Quarter</Text>
              </View>
              <View style={{flex:1, alignItems:'flex-end'}}>
              <Text style={styles.headingDate}>{this.props.date}</Text>
              </View>
            </View>
        
            {list}
            <ProgressDialog
                visible={this.state.loading}
                message="Please Wait.." >
        
           </ProgressDialog>
       
        </ScrollView> 
      </View>
        );
  }
}
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
   
    },
    rankContainer:{ 
      height:60,
      flex:1,
      paddingTop:15,
      alignItems:'flex-start'
      },
   
     ranktext:{
       fontSize:20,
       fontWeight:'bold',
     },
     viewContainer:{
      flex:6,
      flexDirection:'row',
     },
     img:{
        width:50,
        height:50
     },
    contain:{
      padding:5,
      width:Dimensions.get('window').width/1.05,
      height:60,
      alignItems:'center',
     flexDirection:'row',
     borderBottomColor: '#eff0f1',
     borderBottomWidth: 1,
     marginRight:10,
     marginLeft:10
    },
    contain2:{
      padding:5,
     width:Dimensions.get('window').width/1.05,
     height:60,
     alignItems:'center',
     flexDirection:'row',
     borderBottomColor: '#eff0f1',
     borderBottomWidth: 1,
     marginRight:10,
     marginLeft:10,
     backgroundColor: '#E91E63',
  
    },
  heading:{ 
    fontWeight: "bold",
    fontSize:15,
    color:'#000000',
    padding :10,
  },
  headingDate:{  
    fontSize:15,
    color:'#FF0000',
    padding :10,
  },
 
  addFriend:{
    height:30,
    width:90,
    alignItems: 'center',
    right:0,
    padding:5,
    backgroundColor:'#1d93d6'
  },
  alreadyFriend:{
    
    height:30,
    right:0,
    padding:5,
    alignItems: 'center',
    backgroundColor:'#B00020'
  },
  friendText:{
    fontSize:12,
    color:'#FFFFFF',
    height:'100%',
    textAlign:'center'
  }
});

export default TopHundread;